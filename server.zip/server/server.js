const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;
const DATA_DIR = path.join(__dirname, 'data');

app.use(express.json({ limit: '50mb' }));

app.use('/api/', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
});

app.get(['/', '/index.html'], (req, res) => {
    res.sendFile(path.join(__dirname, 'server_index.html'));
});

app.use(express.static(__dirname));

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const STORES = ['users', 'classes', 'students', 'records', 'reports', 'departments', 'configs', 'receiverAccounts', 'generalAccounts'];

function getDataFile(store) {
    return path.join(DATA_DIR, `${store}.json`);
}

function readStore(store) {
    const file = getDataFile(store);
    if (!fs.existsSync(file)) return [];
    try { return JSON.parse(fs.readFileSync(file, 'utf-8')); }
    catch { return []; }
}

function writeStore(store, data) {
    fs.writeFileSync(getDataFile(store), JSON.stringify(data, null, 2), 'utf-8');
}

function getNextId(store) {
    const data = readStore(store);
    if (store === 'configs') return undefined;
    if (data.length === 0) return 1;
    return Math.max(...data.map(item => item.id || 0)) + 1;
}

function seedData() {
    const users = readStore('users');
    if (users.length > 0) return;

    const configs = [
        {
            key: 'meal_prices',
            male: { 1: 5, 2: 12, 3: 10, 4: 5 },
            female: { 1: 5, 2: 10, 3: 8, 4: 5 }
        },
        {
            key: 'meal_sessions',
            day: [
                { id: 1, name: '早餐', enabled: true, time: '07:00-08:00' },
                { id: 2, name: '午餐', enabled: true, time: '11:30-13:00' },
                { id: 3, name: '晚餐', enabled: true, time: '17:30-19:00' }
            ],
            resident: [
                { id: 1, name: '早餐', enabled: true, time: '07:00-08:00' },
                { id: 2, name: '午餐', enabled: true, time: '11:30-13:00' },
                { id: 3, name: '晚餐', enabled: true, time: '17:30-19:00' },
                { id: 4, name: '夜宵', enabled: false, time: '21:00-22:00' }
            ]
        },
        {
            key: 'meal_statuses',
            statuses: [
                { id: 1, name: '正常就餐', rule: 'full', isAttendance: true },
                { id: 2, name: '当日请假（正常扣费）', rule: 'full', isAttendance: false },
                { id: 3, name: '提前请假（不扣费）', rule: 'zero', isAttendance: false }
            ]
        }
    ];
    writeStore('configs', configs);

    writeStore('users', [
        { id: 1, username: 'admin', password: 'admin123', role: 'admin', name: '系统管理员' },
        { id: 2, username: 'zhuren1', password: '123456', role: 'teacher', name: '张老师', classId: 1 },
        { id: 3, username: 'zhuren2', password: '123456', role: 'teacher', name: '李老师', classId: 2 }
    ]);

    writeStore('classes', [
        { id: 1, name: '高一(1)班', department: '计算机系', grade: '高一', classNumber: 1, fullName: '计算机系高一(1)班' },
        { id: 2, name: '高一(2)班', department: '计算机系', grade: '高一', classNumber: 2, fullName: '计算机系高一(2)班' }
    ]);

    writeStore('students', [
        { id: 1, classId: 1, studentNo: '2024001', name: '张三', gender: 'male', studentType: 'day' },
        { id: 2, classId: 1, studentNo: '2024002', name: '李四', gender: 'male', studentType: 'resident' },
        { id: 3, classId: 1, studentNo: '2024003', name: '王五', gender: 'male', studentType: 'day' },
        { id: 4, classId: 1, studentNo: '2024004', name: '赵芳', gender: 'female', studentType: 'day' },
        { id: 5, classId: 1, studentNo: '2024005', name: '孙丽', gender: 'female', studentType: 'resident' },
        { id: 6, classId: 2, studentNo: '2024101', name: '刘强', gender: 'male', studentType: 'day' },
        { id: 7, classId: 2, studentNo: '2024102', name: '陈浩', gender: 'male', studentType: 'day' },
        { id: 8, classId: 2, studentNo: '2024103', name: '周敏', gender: 'female', studentType: 'day' },
        { id: 9, classId: 2, studentNo: '2024104', name: '吴静', gender: 'female', studentType: 'day' },
        { id: 10, classId: 2, studentNo: '2024105', name: '郑婷', gender: 'female', studentType: 'day' }
    ]);

    writeStore('departments', [
        { id: 1, name: '计算机系' },
        { id: 2, name: '护理系' },
        { id: 3, name: '药剂系' }
    ]);

    writeStore('receiverAccounts', [
        { id: 1, account: 'jiaowu', password: '123456', remark: '教务处接收端', permissionType: 'all', permissionIds: [] },
        { id: 2, account: 'jsj_jieshou', password: '123456', remark: '计算机系接收端', permissionType: 'departments', permissionIds: ['计算机系'] }
    ]);

    writeStore('generalAccounts', [
        { id: 1, account: 'zongwu', password: '123456', remark: '总务处', status: 'enabled', createTime: new Date().toISOString().split('T')[0] }
    ]);

    const today = new Date().toISOString().split('T')[0];
    const records = [];
    let rid = 1;
    [1, 2, 3, 4, 5].forEach(sid => {
        const s = readStore('students').find(x => x.id === sid);
        if (!s) return;
        const statusId = s.gender === 'female' ? 3 : 1;
        const cost = statusId === 3 ? 0 : (s.gender === 'male' ? 12 : 10);
        records.push({ id: rid++, studentId: s.id, classId: 1, date: today, mealId: 2, statusId, cost, isAttendance: statusId === 1 });
    });
    writeStore('records', records);

    writeStore('reports', []);

    console.log('初始数据已写入 data/ 目录');
}

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const users = readStore('users');
    const user = users.find(u => u.username === username && u.password === password);
    if (user) return res.json({ success: true, user });

    const receivers = readStore('receiverAccounts');
    const receiver = receivers.find(r => r.account === username && r.password === password);
    if (receiver) return res.json({ success: true, user: { id: receiver.id, username: receiver.account, password: receiver.password, name: receiver.remark, role: 'receiver', permissionType: receiver.permissionType, permissionIds: receiver.permissionIds } });

    const generals = readStore('generalAccounts');
    const general = generals.find(g => g.account === username && g.password === password);
    if (general) return res.json({ success: true, user: { id: general.id, username: general.account, password: general.password, name: general.remark, role: 'general', status: general.status } });

    res.json({ success: false, message: '用户名或密码错误' });
});

app.get('/api/:store', (req, res) => {
    const store = req.params.store;
    if (!STORES.includes(store)) return res.status(400).json({ error: 'Invalid store' });
    let data = readStore(store);
    const { index, value } = req.query;
    if (index && value) {
        const val = isNaN(value) ? value : Number(value);
        data = data.filter(item => {
            if (item[index] === val) return true;
            if (Array.isArray(item[index]) && item[index].includes(val)) return true;
            return false;
        });
    }
    res.json(data);
});

app.get('/api/:store/:id', (req, res) => {
    const store = req.params.store;
    const id = req.params.id;
    if (!STORES.includes(store)) return res.status(400).json({ error: 'Invalid store' });
    const data = readStore(store);
    if (store === 'configs') {
        const item = data.find(item => item.key === id);
        return item ? res.json(item) : res.json(null);
    }
    const numId = Number(id);
    const item = data.find(item => item.id === numId);
    item ? res.json(item) : res.json(null);
});

app.post('/api/:store', (req, res) => {
    const store = req.params.store;
    if (!STORES.includes(store)) return res.status(400).json({ error: 'Invalid store' });
    const data = readStore(store);
    const item = req.body;
    if (store === 'configs') {
        const idx = data.findIndex(d => d.key === item.key);
        if (idx >= 0) data[idx] = item;
        else data.push(item);
    } else {
        if (!item.id) item.id = getNextId(store);
        data.push(item);
    }
    writeStore(store, data);
    res.json(item);
});

app.put('/api/:store/:id', (req, res) => {
    const store = req.params.store;
    const id = req.params.id;
    if (!STORES.includes(store)) return res.status(400).json({ error: 'Invalid store' });
    const data = readStore(store);
    const item = req.body;
    if (store === 'configs') {
        const idx = data.findIndex(d => d.key === id);
        if (idx >= 0) { data[idx] = item; writeStore(store, data); return res.json(item); }
        data.push(item);
        writeStore(store, data);
        return res.json(item);
    }
    const numId = Number(id);
    const idx = data.findIndex(d => d.id === numId);
    if (idx >= 0) { data[idx] = item; writeStore(store, data); return res.json(item); }
    res.json(null);
});

app.delete('/api/:store/:id', (req, res) => {
    const store = req.params.store;
    const id = req.params.id;
    if (!STORES.includes(store)) return res.status(400).json({ error: 'Invalid store' });
    const data = readStore(store);
    if (store === 'configs') {
        const filtered = data.filter(d => d.key !== id);
        writeStore(store, filtered);
        return res.json({ success: true });
    }
    const numId = Number(id);
    const filtered = data.filter(d => d.id !== numId);
    writeStore(store, filtered);
    res.json({ success: true });
});

app.post('/api/bulk/:store', (req, res) => {
    const store = req.params.store;
    if (!STORES.includes(store)) return res.status(400).json({ error: 'Invalid store' });
    const items = req.body;
    if (!Array.isArray(items)) return res.status(400).json({ error: 'Body must be array' });
    const data = readStore(store);
    for (const item of items) {
        if (store === 'configs') {
            const idx = data.findIndex(d => d.key === item.key);
            if (idx >= 0) data[idx] = item;
            else data.push(item);
        } else {
            if (!item.id) item.id = getNextId(store);
            const idx = data.findIndex(d => d.id === item.id);
            if (idx >= 0) data[idx] = item;
            else data.push(item);
        }
    }
    writeStore(store, data);
    res.json({ success: true, count: items.length });
});

app.post('/api/clear/:store', (req, res) => {
    const store = req.params.store;
    if (!STORES.includes(store)) return res.status(400).json({ error: 'Invalid store' });
    writeStore(store, []);
    res.json({ success: true });
});

seedData();

function migrateReports() {
    const reports = readStore('reports');
    if (reports.length === 0) return;

    const students = readStore('students');
    const records = readStore('records');
    let migrated = 0;

    reports.forEach(report => {
        if (report.presentCount !== undefined && report.absentCount !== undefined && report.mealCount !== undefined) return;

        const classStudents = students.filter(s => s.classId === report.classId);
        const classRecords = records.filter(r => r.classId === report.classId && r.date === report.date);

        const presentStudentIds = new Set(classRecords.filter(r => r.isAttendance).map(r => r.studentId));
        const absentStudentIds = classStudents.filter(s => !presentStudentIds.has(s.id)).map(s => s.id);

        report.totalCount = classStudents.length;
        report.presentCount = presentStudentIds.size;
        report.absentCount = absentStudentIds.length;
        report.mealCount = classRecords.filter(r => r.isAttendance).length;
        report.attendedCount = presentStudentIds.size;
        migrated++;
    });

    if (migrated > 0) {
        writeStore('reports', reports);
        console.log(`数据迁移完成：已修复 ${migrated} 条上报记录的人数/人次字段`);
    }
}

migrateReports();

app.listen(PORT, '0.0.0.0', () => {
    console.log(`=================================`);
    console.log(`  就餐管理系统服务器已启动`);
    console.log(`  本机访问: http://localhost:${PORT}`);
    console.log(`  局域网访问: http://<服务器IP>:${PORT}`);
    console.log(`=================================`);
});
